<?php 
$_ENV['DB_HOST'] = 'localhost';
$_ENV['DB_NAME'] = 'agenda_contactos';
$_ENV['DB_USER'] = 'root';
$_ENV['DB_PASS'] = '';